
#include <iostream>
#include <fstream>
#include "graphType.h"
 
using namespace std; 

int main()
{
    cout << "See Programming Exercises 1 and 2" << endl;

    return 0;
} 