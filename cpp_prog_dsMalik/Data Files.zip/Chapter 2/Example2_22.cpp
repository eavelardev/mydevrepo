// This program illustrates how output statements work.
  
#include <iostream>                     //Line 1
 
using namespace std;                    //Line 2

int main()                              //Line 3
{                                       //Line 4
    int a, b;                           //Line 5
 
    a = 65;                             //Line 6
    b = 78;                             //Line 7

    cout << 29 / 4 << endl;             //Line 8
    cout << 3.0 / 2 << endl;            //Line 9
    cout << "Hello there.\n";           //Line 10
    cout << 7 << endl;                  //Line 11
    cout << 3 + 5 << endl;              //Line 12
    cout << "3 + 5";                    //Line 13
    cout << " **";                      //Line 14
    cout << endl;                       //Line 15
    cout << 2 + 3 * 6 << endl;          //Line 16
    cout << "a" << endl;                //Line 17
    cout << a << endl;                  //Line 18
    cout << b << endl;                  //Line 19
    
    return 0;                           //Line 20
}                                       //Line 21
