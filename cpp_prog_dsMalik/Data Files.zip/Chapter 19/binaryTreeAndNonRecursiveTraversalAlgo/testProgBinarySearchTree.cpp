 
#include <iostream>
#include "binarySearchTree.h"

using namespace std;

int main() 
{
	cout << "See programming exercise 6." << endl;

	return 0;
}  