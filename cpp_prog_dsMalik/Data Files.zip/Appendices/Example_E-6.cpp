//Reading a file randomly 

#include <iostream>                                 //Line 1
#include <fstream>                                  //Line 2
#include <iomanip>                                  //Line 3
  
using namespace std;                                //Line 4

struct customerType                                 //Line 5
{                                                   //Line 6
    char firstName[15];                             //Line 7
    char lastName[15];                              //Line 8
    int ID;                                         //Line 9
    double balance;                                 //Line 10
};                                                  //Line 11

void printCustData(const customerType& customer);   //Line 12

int main()                                          //Line 13
{                                                   //Line 14
    customerType cust;                              //Line 15
    ifstream inFile;                                //Line 16

    long custSize = sizeof(cust);                   //Line 17

    inFile.open("customer.dat", ios::binary);       //Line 18

    if (!inFile)                                    //Line 19
    {                                               //Line 20
        cout << "The input file does not exist. "
             << "The program terminates!!" << endl; //Line 21
        return 1;                                   //Line 22
    }                                               //Line 23

    cout << fixed << showpoint << setprecision(2);  //Line 24

        //randomly read the records and outputs them
    inFile.seekg(6 * custSize, ios::beg);           //Line 25
    inFile.read(reinterpret_cast<char *> (&cust),
                sizeof(cust));                      //Line 26
    cout << "Seventh customer's data: " << endl;    //Line 27
    printCustData(cust);                            //Line 28 

    inFile.seekg(8 * custSize, ios::beg);           //Line 29
    inFile.read(reinterpret_cast<char *> (&cust),
                sizeof(cust));                      //Line 30
    cout << "Ninth customer's data: " << endl;      //Line 31
    printCustData(cust);                            //Line 32

    inFile.seekg(-8 * custSize, ios::end);          //Line 33
    inFile.read(reinterpret_cast<char *> (&cust),
                sizeof(cust));                      //Line 34
    cout << "Eighth (from the end) customer's "
         << "data: " << endl;                       //Line 35
    printCustData(cust);                            //Line 36

    inFile.close();     //close the file            //Line 37

    return 0;                                       //Line 38
}                                                   //Line 39

void printCustData(const customerType& customer)    //Line 40
{                                                   //Line 41
    cout << "  ID: " << customer.ID <<endl
         << "  First Name: " << customer.firstName << endl
         << "  Last Name: " << customer.lastName << endl
         << "  Account Balance: $" << customer.balance
         << endl;                                   //Line 42
}                                                   //Line 43
