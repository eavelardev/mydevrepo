 
#include <iostream>                                 //Line 1
#include <fstream>                                  //Line 2

using namespace std;                                //Line 3
 
int main()                                          //Line 4
{                                                   //Line 5
    char ch;                                        //Line 6
    ifstream inFile;                                //Line 7

    inFile.open("digitsAndAlphabet.txt");           //Line 8

    if (!inFile)                                    //Line 9
    {                                               //Line 10
       cout << "The input file does not exist. "
            << "The program terminates!!" << endl;  //Line 11
       return 1;                                    //Line 12
    }                                               //Line 13

    inFile.get(ch);                                 //Line 14
    cout << "Line 15: The first byte: " << ch
         << endl;                                   //Line 15

      //position the reading marker six bytes to the 
      //right of its current position
    inFile.seekg(6L, ios::cur);                     //Line 16 
    inFile.get(ch);  //read the character           //Line 17
    cout << "Line 18: Current byte read: " << ch
         << endl;                                   //Line 18

      //position the reading marker seven bytes 
      //from the beginning
    inFile.seekg(7L, ios::beg);                     //Line 19
    inFile.get(ch);  //read the character           //Line 20
    cout << "Line 21: Seventh byte from the "
         << "beginning: " << ch << endl;            //Line 21

      //position the reading marker 26 bytes 
      //from the end
    inFile.seekg(-26L, ios::end);                   //Line 22
    inFile.get(ch);  //read the character           //Line 23
    cout << "Line 24: Byte 26 from the end: " << ch
         << endl;                                   //Line 24

    return 0;                                       //Line 25
}                                                   //Line 26
