#include <iostream>

using namespace std;
 
int main() 
{ 
    cout << "My first C++ program." << endl;

    return 0;
}   
